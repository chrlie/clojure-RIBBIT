RIBBIT
======

::

                           '.  ckO,
                         .xKOXXkkNko                            ';
                        0xoclodOkkKKKd;.      .       .        .... .
                        do'.  ':lxK0KkXWxkOOkOddl';;.  .  .      .,        ..;.
                         .:.     ,dxXOWKcxdKcxkkkdokOKll.. ..  .  ;   .  ..   '
             .    .       .c      'dx0OKddXKOdx0KXxcOxkNKo   '.   :. . .'
            . .. ;,      . c,      ::xdNkkdlxxkOdkkK000WXX0l'.'. .d.' ...''..
         ....... ,  ....  .;x'     .cxONkKXNO0K0KXKNKKXWWWNWNk:;.,d;,l','.'  . ...
        ...'',::c'.........c0Oc..  .'oOX0NOXkKx0XNXOxKWWWXXK0dl',l0dkc;;.... ... ..
       .....;cx.';.....,::;:xNN0l,..'';OXNKkdxNWKkkxXKOKKOXWKO0dokN0l;'.. .  .
      .....';oklccdodl:clllolONXKKl,,;;oNKO0kxNX0OKNXNXN0XKdxKKOdXWOx:,..
     .';:,'..':,.,,,,'......:XXNXxk::;.dNKX0ONXKxxOOkO0OOOKX0kkKXXkoc.
     ..,;::,,:;......''.':,;:,;dx';ld0xkOXKKkoclkkx0XX0OOxOkkXK0d:;,'..
             .    ...':clc::;,'',;lOKO000kxkOOxcllkdooOKxkKOkdc,,..
                   .,:;:ocooccllc::cc:;,',,'.....oo,.oc,'..
                            .......   ...'..    c'....

Clojure RIBBIT client.

Quick start
-------------------------

```clojure

(:require [ribbit

    from RIBBIT.client import RIBBITClient
    client = RIBBITClient()
    client.croak()
    client.frog_tip()


A Clojure library designed to ... well, that part is up to you.

## Usage

FIXME

## License

Copyright © 2016 FIXME

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
